# Kaka Websites

Static, single-file HTML e-commerce catalogue sites — no backend, WhatsApp-enquiry only.

## Sites

- **kaka-shoe-plaza/** — Kaka Shoe Plaza, footwear store in Satna, MP
- **kaka-weld-hub/** — Kaka Weld Hub, welding equipment dealer in Raipur, CG

Each site is a self-contained `index.html` plus a `*-data.json` file with product/category/FAQ data.
The HTML fetches its own JSON file at load time (falling back to its own embedded data if the fetch fails — e.g. when opened via `file://` instead of a real web server).

## Running locally

Each site needs to be served over HTTP for the JSON fetch to work (opening the HTML file directly via double-click will silently fall back to embedded data instead):

```bash
cd kaka-shoe-plaza && python3 -m http.server 8000
# then open http://localhost:8000
```

## Deploying

Each folder can be published as-is to GitHub Pages, Netlify, or any static host — just make sure the `index.html` and its matching `*-data.json` file stay in the same folder.
